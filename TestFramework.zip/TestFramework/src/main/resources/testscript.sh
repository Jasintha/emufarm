#!/bin/sh

function showUsageAndExit() {
  echo "Insufficient or invalid options provided!"
  echo
  echo "Usage: ./testscript.sh -d [device] -n [noOfDevices] -a [agentUrl]"
  echo

  echo "Options:"
  echo
  echo -en "  -d\t"
  echo "[REQUIRED] Device. Ex: avd19, avd22, avd23 ..."
  echo -en "  -n\t"
  echo "[REQUIRED] No of Devices"
  echo -en "  -a\t"
  echo "[REQUIRED] Agent URL"
  echo

  echo "Ex: ./testscript.sh -d avd19 -n 2 -a https://iotserver.com/agent1 "

  echo
  exit 1
}

function isAvdExist() {
    #TODO: to check if the avd exist
    if [ ${1} ]
        then
            # 0 = true
            return 0
        else
            # 1 = false
            return 1
    fi
}

function createAvd() {
    echo "creating avd ${1}"
    #TODO: create the avd
    android create avd -n ${1} -t 1
}

function startEmulator () {

    EMULATOR_PORT=$((5556 + (${3} * 2)))
    EXEC_FILE="emulator"

#TODO: check if the avd exist, if not create the avd
#    if [isAvdExist ${1}]
#        then
#            AVD_NAME=${1}
#        else
#            echo "AVD ${1} doesn't exist!"
#    fi

    AVD_NAME=${1}
    #AGENT_PATH=/home/wso2/scripts
    AGENT_PATH=/Users/vizzy/Desktop/IOT/TestFramework/src/main/resources

    EMULATOR_PORT=$((5554 + (${3} * 2)))

    EXEC_FILE="emulator"

    echo no | android create avd -n name -t 9

    echo "\t\t \n\n ****************** emulator-${EMULATOR_PORT} ************************"
    #${EXEC_FILE} -avd ${AVD_NAME} -port ${EMULATOR_PORT} -no-boot-anim -no-skin -no-window &

    echo "\t\t \n\n ****************** Step 1 - Creating the AVD ************************"

    echo no | android create avd -n avdnew17-${3} -t 3 --abi default/x86

    echo "\t\t \n\n ****************** Step 2 - Starting the emulator using created AVD ************************"

    ${EXEC_FILE} -netdelay none -netspeed full -avd avdnew17-${3} -prop emu.uuid=5ec33f90-a471-11e2-9e96-${EMULATOR_PORT} -port ${EMULATOR_PORT} -no-window &
    #emulator -netdelay none -netspeed full -avd ${AVD_NAME} -port ${EMULATOR_PORT}   -no-window

    echo "Waiting until emulator loaded"
    while [ "`adb -s emulator-${EMULATOR_PORT} get-state`" != "device" ] ;do sleep 2; done

    sleep 1 ;
    echo "Waiting until emulator ready to install agent"
    retrycout=0;
    timeout=20;
    while [ "`adb -s emulator-${EMULATOR_PORT} shell getprop sys.boot_completed | tr -d '\r' `" != "1" ] ;
          do

            let retrycout=retrycout+1;
           if [ ${retrycout} -lt ${timeout} ] ; then
               echo "retry ${retrycout} after 3 seconds"
               sleep 1;
            else
              let retrycout=0;
              echo " killing the emulator-"${EMULATOR_PORT}
              adb -s adb -s emulator-${EMULATOR_PORT} emu kill
              sleep 2;
              echo "start the emulator again !"
              emulator -netdelay none -netspeed full -avd avdnew17-${3} -prop emu.uuid=5ec33f90-a471-11e2-9e96-${EMULATOR_PORT} -port ${EMULATOR_PORT} -no-window &
              echo "Waiting until emulator loaded"
              while [ "`adb -s emulator-${EMULATOR_PORT} get-state`" != "device" ] ;do sleep 2; done
           fi
    done

    echo "Send the agent into the device"
    adb -s emulator-${EMULATOR_PORT} push ${AGENT_PATH}/client-debug.apk /data/local/tmp/org.wso2.emm.agent

    echo "install the agent"
    adb -s emulator-${EMULATOR_PORT} shell pm install -r "/data/local/tmp/org.wso2.emm.agent"

    echo "execute the application"
    adb -s emulator-${EMULATOR_PORT} shell am start -n "org.wso2.emm.agent/org.wso2.emm.agent.AgentReceptionActivity" -a android.intent.action.MAIN -c android.intent.category.LAUNCHER &

}


while getopts :d:n:a: FLAG; do
  case ${FLAG} in
    d)
      device=$OPTARG
      ;;
    n)
      noOfDevices=$OPTARG
      ;;
    a)
      agentUrl=$OPTARG
      ;;
    \?)
      showUsageAndExit
      ;;
  esac
done

echo "Device: ${device} _+_ NoOfDevices: ${noOfDevices} _+_ AgentURL: ${agentUrl}";

COUNTER=0
while [  ${COUNTER} -lt ${noOfDevices} ]; do
    startEmulator ${device} ${agentUrl} ${COUNTER}
    let COUNTER=COUNTER+1
done
