package org.wso2.iot;


import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.wso2.iot.emu.data.H2MachineInfoDatabase;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

@Path("/iot")
public class RestService {

	private static final String EMU_CREATE_EP = "createemu";
	private static final String EMU_OP_EP = "emuoperation";

	private static final String API_19_DEVICE = "avd19";

	private static final String API_21_DEVICE = "avd21";

	private static final String API_22_DEVICE = "avd22";

	private static final String API_23_DEVICE = "avd23";

	private static final String API_24_DEVICE = "avd24";

	private static final String ADB_DEVICES_LIST_COMMAND = "/Users/jasintha/Library/Android/sdk/platform-tools/adb devices";

	private static final String KILL_EMU = "kill";

	private static final String LOGS = "log";

	private static final Logger LOGGER = Logger.getLogger(RestService.class.getName());

	private static final String propertiesFileName = "config/config.properties";
	public static final String List_AVILABLE_DEVICE = "lad";
	Properties properties = new Properties();

	InputStream inputStream;
	StringBuffer processError = new StringBuffer();
	StringBuffer processOutput = new StringBuffer();
	String deviceType;

	public String getProperties(String key) throws IOException {
		String value = "";
		try {
			inputStream = getClass().getClassLoader().getResourceAsStream(propertiesFileName);

			if (inputStream != null) {
				properties.load(inputStream);

				value = properties.getProperty(key);
			} else {
				throw new FileNotFoundException(
						"property file '" + propertiesFileName + "' not found in the classpath");
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getStackTrace().toString());
		}

		return value;
	}

	@GET
	@Path("/test/{param}")
	public Response getMsg(@PathParam("param") String msg) throws IOException {

		String output = "Jersey say URL : " + getProperties("SCRIPT_PATH");
		return Response.status(200).entity(output).build();

	}


	@GET
	@Path("/listDevices")
	@Produces("application/json")
	public Response getMsg() {

		String output = "{\"android\":{\"android-15\", \"android-17\", \"android-19\"}, \"iOS\":{\"iOS1\", \"iOS2\"}, \"windows\":{\"win1\",\"win2\"}}";

		return Response.status(200).entity(output).build();
	}

	@POST
	@Path("/createTest")
	public Response createTest(@FormParam("device") final String device,
			@FormParam("noOfDevices") final int noOfDevices, @FormParam("agentUrl") final String agentUrl) {
          System.out.println("CretateTest -Manager");
		/*{"deviceType":"avd24","count":5,"emuType":"emulator","emmHost":"10.0.2.2:9763","apk":"null","script":"null"}*/
		String output = "Emulators spin up successfully";
		try {
			JSONArray retriveAvillableMachines = H2MachineInfoDatabase.retriveAvillableMachines("true");
			if(retriveAvillableMachines.length()!=0){
				 int remainingDevices = noOfDevices;				 					
					for (Object object : retriveAvillableMachines) {						
						JSONObject machine = (JSONObject) object;
						int machinCapcity =Integer.parseInt(machine.getString("capacity")); 					    
				    	 JSONObject request = new JSONObject();
				    	 request.put("deviceType", device);				    	 
				    	 request.put("emuType", machine.getString("emuType"));
				    	 request.put("emmHost", agentUrl);
				    	 request.put("apk", "null");
				    	 request.put("script", "null");				    	 
					     if(machinCapcity<remainingDevices){					    	 
					    	 request.put("count", machinCapcity);
					     }else{
					    	 request.put("count", remainingDevices);					    	 
					     }
					     output = startEmu(machine.getString("ip"),request.toString(),EMU_CREATE_EP);
					     H2MachineInfoDatabase.updateMachinesStatus("false", machine.getString("ip"));					     
					     remainingDevices = remainingDevices - machinCapcity;
					     if(remainingDevices <= 0){
					    	 break;
					     }
					}					
			}else{
				output = "Sorry ! There are no free emulators to run this test";				
			}						
		} catch (Exception e) {
			output = e.getMessage();
			e.printStackTrace();
		}
  
		return Response.status(200).entity(output).build();
	}
	
	
	

	@GET
	@Path("/devices")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getDevices() {
      		String respond="";
      		JSONArray records = new JSONArray();
		try {
			JSONArray retriveAvillableMachines = H2MachineInfoDatabase.retriveAvillableMachines("true");
			if(retriveAvillableMachines.length()!=0){				 					
					for (Object object : retriveAvillableMachines) {
						
						 JSONObject machine = (JSONObject) object;					    
				    	 JSONObject request = new JSONObject();
				    	 request.put("opname", "lad");				    	 
				    	 request.put("deviceId", "all");
				    	 request.put("ip", machine.getString("ip"));		
				    	 respond = startEmu(machine.getString("ip"),request.toString(),EMU_OP_EP); 
				    	 JSONArray resultArry = new JSONArray(respond);
				    	 for (Object emuObject : resultArry) {
							JSONObject emulator = (JSONObject) emuObject;
							records.put(emulator);
						}
					}
					
			}else{
				respond = "There are no availble emulators to run this test";				
			}					
			 JSONObject mainObject = new JSONObject();
			 mainObject.put("records", records);
			 respond=mainObject.toString();
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		System.out.println("output : "+respond);
		return Response.status(200).entity(respond).build();
	}

	@GET
	@Path("/devices/{opname}/{deviceId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response execadb(@PathParam("opname") final String opname, @PathParam("deviceId") final String deviceId) {

		String respond ="";
		try {

			JSONObject request = new JSONObject();
			request.put("opname", opname);
			request.put("deviceId", deviceId.split("_")[0]);
			request.put("ip", deviceId.split("_")[1]);
			respond = startEmu(deviceId.split("_")[1], request.toString(), EMU_OP_EP);

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("output : " + respond);
		return Response.status(200).entity(respond).build();
	}
	
	@GET
	@Path("/machines")
	@Produces("application/json")
	public Response getMachines() throws IOException {
		JSONArray machines;
		try {			
			machines = H2MachineInfoDatabase.retriveMachines();
		} catch (SQLException e) {
			 machines = new JSONArray();
		}				
		String result = machines.toString();		
		return Response.status(200).entity(result).build();

	}
	
	@POST
	@Path("/machines/save")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response saveMachines(String machine) throws IOException {
		 
		System.out.println("I am post+"+machine);
		JSONObject machineJson = new JSONObject(machine);
		try {		
			H2MachineInfoDatabase.insertWithStatement(machineJson.getString("Machine IP"),
					""+machineJson.getInt("capacity"), "true",machineJson.getString("emuType"));
		   //	machines = H2MachineInfoDatabase.retriveMachines();
		} catch (SQLException e) {
		 //	 machines = new JSONArray();
		}	
		JSONArray machinesArray = new JSONArray();
		machinesArray.put(200);
		JSONObject resultJson = new JSONObject();
		resultJson.putOnce("status", "ok");
		machinesArray.put(resultJson);
		System.out.println(machinesArray.toString());
		return Response.status(200).entity(machinesArray.toString()).build();
	}
	
	@POST
	@Path("/machines/remove")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response removeMachines(String machine) throws IOException {
		 		
		JSONObject machineJson = new JSONObject(machine);
		String status="OK";
		try {		
			H2MachineInfoDatabase.deleteMachinesStatus(machineJson.getString("ip"));
		} catch (SQLException e) {
		  status="Fail";
		}	
		JSONArray machinesArray = new JSONArray();
		machinesArray.put(200);
		JSONObject resultJson = new JSONObject();
		resultJson.putOnce("status", status);
		machinesArray.put(resultJson);
		System.out.println(machinesArray.toString());
		return Response.status(200).entity(machinesArray.toString()).build();
	}
	
	
	private String startEmu(String host,String request,String endpoint) throws IOException{
		
	  			URL url = new URL("http://"+host+"/iot/"+endpoint);
	  			HttpURLConnection conn = (HttpURLConnection) url.openConnection();	
	  			conn.setDoOutput(true);
	  			conn.setRequestMethod("POST");
	  			conn.setRequestProperty("content-type", "application/json");
	  			OutputStream os = conn.getOutputStream();
	  			os.write(request.getBytes());
	  			os.flush();

	  			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
	  				throw new RuntimeException("Failed : HTTP error code : "
	  					+ conn.getResponseCode());
	  			}
 
	  			BufferedReader br = new BufferedReader(new InputStreamReader(
	  					(conn.getInputStream())));

	  			String output;
	  			StringBuffer processOutput = new StringBuffer();
	  			while ((output = br.readLine()) != null) {
	  				processOutput.append(output);
	  			}
	  			
	  			conn.disconnect();
	  			return processOutput.toString();
  
	}
	
	
	
	
	
	
	
/*
 * 
          if (API_24_DEVICE.equals(device)){
        	  deviceType="android-24";
          }else if(API_23_DEVICE.equals(device)){
        	  deviceType="android-23";
          }else if(API_22_DEVICE.equals(device)){
        	  deviceType="android-22";
          }else if(API_21_DEVICE.equals(device)){
        	  deviceType="android-21";
          }else if(API_19_DEVICE.equals(device)){
        	  deviceType="android-19";
          }
		
		
		Thread anonymous = new Thread() {
		
			@Override
			public void run() {

				MainTest test = new MainTest();
				Runtime runtime = Runtime.getRuntime();
				Process process = null;
				StringBuffer processOutput = new StringBuffer();
				StringBuffer processError = new StringBuffer();
				String respond = "";

				try {

					String BASH = "/bin/bash";
					String SCRIPT_PATH = test.getProperties("SCRIPT_PATH");

					String outInput = "";
					String outError = "";

					String[] cmd = new String[] { BASH, SCRIPT_PATH, "-d", deviceType, "-n", Integer.toString(noOfDevices),
							"-a", agentUrl };
					process = runtime.exec(cmd);
					BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
					BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
					while ((outInput = stdInput.readLine()) != null) {
						System.out.println(outInput);
						processOutput.append(outInput + "\n");
					}
					while ((outError = stdError.readLine()) != null) {
						processError.append(outError + "\n");
						System.out.println(outError);
					}

				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					process.destroy();
				}

			}
		};
		anonymous.start();

 * 
 * 
 */
	/*
	private String abdOP(final String opname, final String deviceId) {
		String respond = "";
		JSONArray resultArray = new JSONArray();
		Thread anonymous = new Thread() {
			@Override
			public void run() {
				Runtime runtime = Runtime.getRuntime();
				Process process = null;
				try {
					String outInput = "";
					String outError = "";
					String cmd = "";
					if (List_AVILABLE_DEVICE.equals(opname)) {
						cmd = ADB_DEVICES_LIST_COMMAND;
					} else if (LOGS.equals(opname)) {
						cmd = "adb -s " + deviceId + " logcat";
					} else if (KILL_EMU.equals(opname)) {
						cmd = "adb -s " + deviceId + " emu kill";
					} else if ("targets".equals(opname)) {

						cmd = "/Users/jasintha/Library/Android/sdk/tools/	 list target";
					}
					process = runtime.exec(cmd);
					BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
					BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
					while ((outInput = stdInput.readLine()) != null) {

						if ("targets".equals(opname)) {
							if (outInput != null && outInput.startsWith("-----")) {
								processOutput.append("\n");
							}
							if (outInput != null && (outInput.startsWith("id:") || outInput.contains("default/x86"))) {
								processOutput.append(outInput);
							}
						} else {
							processOutput.append(outInput + "\n");

						}
					}
					while ((outError = stdError.readLine()) != null) {
						processError.append(outError + "\n");
					}

				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					process.destroy();
				}

			}
		};
		anonymous.start();
		long startTime = System.currentTimeMillis();
		while (true) {
			if ((System.currentTimeMillis() - startTime) > 3000) {
				break;
			}
		}
		anonymous.stop();

		if (List_AVILABLE_DEVICE.equals(opname)) {
			
			String result = processOutput.toString();
			String lines[] = result.split("\\r?\\n");
			
			for (int num=1; num < lines.length; num++) {
				JSONObject device = new JSONObject();
				//lines[num].split("\\s+")[0]
				device.put("Name", lines[num].split("\\s+")[0]);
				resultArray.put(device);
			}
			
			JSONObject mainObject = new JSONObject();
			mainObject.put("records", resultArray);
			respond = "" + mainObject;
		
		} else if (LOGS.equals(opname)) {
			
			JSONObject mainObject = new JSONObject();
			respond = processOutput.toString();
			mainObject.putOnce("logs", respond);
			
		} else if ("targets".equals(opname)) {
			
			String result = processOutput.toString();
			String lines[] = result.split("\\r?\\n");
			
			for (String line : lines) {
				if (line.contains("Tag/ABIs")) {
					respond = respond + "\n" + line.split("\\s+")[3];
					JSONObject targets = new JSONObject();
					targets.put("Id", line.split("\\s+")[0]);
					resultArray.put(targets);
				}
			}
		}
		
		processOutput.delete(0, processOutput.length());
		return respond;
	}
*/
	
	
	
}