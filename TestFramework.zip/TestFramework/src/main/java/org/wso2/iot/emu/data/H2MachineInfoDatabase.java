package org.wso2.iot.emu.data;

import java.io.File;
import java.net.InetAddress;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.h2.tools.DeleteDbFiles;
import org.json.JSONArray;
import org.json.JSONObject;


public class H2MachineInfoDatabase {

    private static final String DB_DRIVER = "org.h2.Driver";
    private static String DB_CONNECTION = "jdbc:h2:";
    private static final String DB_USER = "";
    private static final String DB_PASSWORD = "";
    private static String homeDir;
    
    static{
    	File file=null;
		try {
			file = new File(H2MachineInfoDatabase.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
			homeDir = file.getParent();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
    	DB_CONNECTION = DB_CONNECTION+file.getParent()+"/emu";
    }

    
//    public static void main(String[] args) throws Exception {
//        try {
//            // delete the H2 database named 'test' in the user home directory
//        	deleteDB();
//           /* insertWithStatement("10.100.1.102","80","true");
//            insertWithStatement("10.100.1.204","80","true");
//            insertWithStatement("165.100.1.205","80","true");
//            insertWithStatement("170.100.1.206","80","true");*/
//            
//            
//          //  DeleteDbFiles.execute("~", "test", true);
//          //  insertWithPreparedStatement();
//            retriveMachines();            
//           /* updateMachinesStatus("false", "10.100.1.102");           
//            retriveAvillableMachines();            
//            deleteMachinesStatus("170.100.1.206");
//            retriveMachines();*/
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
    
    public static void setDB(){
    	
    }
    
    public static void deleteDB(){
    	
    	  DeleteDbFiles.execute(homeDir, "emu", true);
    }

    // H2 SQL Prepared Statement Example
    public static JSONArray retriveMachines() throws SQLException {
        Connection connection = getDBConnection();
        Statement stmt = null;
        JSONArray machines = new JSONArray();
        try {
            connection.setAutoCommit(false);
            stmt = connection.createStatement();   
            ResultSet rs = stmt.executeQuery("select * from MACHINE");
            while (rs.next()) {
            	JSONObject machine1 = new JSONObject();
        		machine1.put("id", rs.getInt("id"));
        		machine1.put("ip", rs.getString("ip"));
        		machine1.put("capacity", rs.getString("capacity"));
        		machine1.put("emuType", rs.getString("emuType"));
        		try{
        		if(InetAddress.getByName(rs.getString("ip").split(":")[0]).isReachable(500)){
        			machine1.put("status", 1);
        		}else{
        			machine1.put("status", 2);
        		}
        		}catch(Exception e){
        			machine1.put("status", 2);
        		}
        		machines.put(machine1);               
            }
            System.out.println(machines.toString());
            stmt.close();
            connection.commit();
        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.close();
           
        }
        return machines; 
    }
    
    public static void updateMachinesStatus(String status,String ip) throws SQLException {
        Connection connection = getDBConnection();
        Statement stmt = null;
        try {
            connection.setAutoCommit(false);
            stmt = connection.createStatement();   
            stmt.executeUpdate("update MACHINE set avilable='"+status+"' where ip='"+ip+"'");
            stmt.close();
            connection.commit();
        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.close();
           
        }
    }
    
    public static void deleteMachinesStatus(String ip) throws SQLException {
        Connection connection = getDBConnection();
        Statement stmt = null;
        try {
            connection.setAutoCommit(false);
            stmt = connection.createStatement();   
            stmt.executeUpdate("delete from MACHINE where ip='"+ip+"'");
            stmt.close();
            connection.commit();
        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.close();
           
        }
    }
    
    
    public static JSONArray retriveAvillableMachines(String status) throws SQLException {
        Connection connection = getDBConnection();
        Statement stmt = null;
        JSONArray machines = new JSONArray();
        try {
            connection.setAutoCommit(false);
            stmt = connection.createStatement();   
            ResultSet rs = stmt.executeQuery("select * from MACHINE where avilable='"+status+"'");
            while (rs.next()) { 
        		try{
        		if(InetAddress.getByName(rs.getString("ip").split(":")[0]).isReachable(500)){                  	
        			JSONObject machine1 = new JSONObject();
            		machine1.put("id", rs.getInt("id"));
            		machine1.put("ip", rs.getString("ip"));
            		machine1.put("capacity", rs.getString("capacity"));
            		machine1.put("emuType", rs.getString("emuType"));
        			machine1.put("status", 1);
        			machines.put(machine1);
        		} 
        		}catch(Exception e){
        			/*ignore*/
        		}       		               
            }
            System.out.println(machines.toString());
            stmt.close();
            connection.commit();
        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.close();
           
        }
        return machines; 
    }
    
    // H2 SQL Statement Example
    public static void insertWithStatement(String ip , String capacity ,String avilable,String emuType) throws SQLException {
        Connection connection = getDBConnection();
        Statement stmt = null;
        try {
            connection.setAutoCommit(false);
            stmt = connection.createStatement();
            stmt.execute("CREATE TABLE IF NOT EXISTS MACHINE(id int auto_increment primary key,ip varchar(255),"
            		+ " capacity varchar(255), avilable varchar(255),emuType varchar(255))");                       
            stmt.execute("INSERT INTO MACHINE(ip, capacity, avilable,emuType) VALUES('"+ip+"','"+capacity+"','"+avilable+"','"+emuType+"')");
            stmt.close();
            connection.commit();
        } catch (SQLException e) {
        	e.printStackTrace();
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
    }
    

    private static Connection getDBConnection() {
        Connection dbConnection = null;
        try {
            Class.forName(DB_DRIVER);
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
        try {
            dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER,
                    DB_PASSWORD);
            return dbConnection;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return dbConnection;
    }
}