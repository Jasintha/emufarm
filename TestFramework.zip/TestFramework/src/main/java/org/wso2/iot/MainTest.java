package org.wso2.iot;

import java.io.*;
import java.util.Properties;
import java.util.logging.Level;

/**
 * Created by jasintha on 10/7/16.
 */
public class MainTest {

	public static void main(String[] args) {

		// new InnerRunnable2("InnerRunnable2");

		Thread anonymous = new Thread() {
			@Override
			public void run() {

				MainTest test = new MainTest();
				Runtime runtime = Runtime.getRuntime();
				Process process = null;
				StringBuffer processOutput = new StringBuffer();
				StringBuffer processError = new StringBuffer();
				

				try {

					String BASH = "/bin/sh";
					String SCRIPT_PATH = test.getProperties("SCRIPT_PATH");

					String outInput = "";
					String outError = "";
					String device = "";
					int noOfDevices = 1;
					String agentUrl = "";

					String[] cmd = new String[] { BASH, SCRIPT_PATH, "-d", device, "-n", Integer.toString(noOfDevices),
							"-a", agentUrl };

					process = runtime.exec(cmd);

					BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));

					BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));

					while ((outInput = stdInput.readLine()) != null) {
						System.out.println(outInput);
						processOutput.append(outInput + "\n");
					}
					System.out.println("asasdadasd");

					while ((outError = stdError.readLine()) != null) {
						processError.append(outError + "\n");
						System.out.println(outError);
					}

				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					process.destroy();
				}

				String output = "--- out Input: " + processOutput + "--- out Error: " + processError;
				System.out.println(output);

			}
		};
		anonymous.start();

		System.out.println("Emulator starting process started !!!");
	}

	private static final String propertiesFileName = "config/config.properties";
	Properties properties = new Properties();

	InputStream inputStream;

	public String getProperties(String key) throws IOException {
		String value = "";
		try {
			inputStream = getClass().getClassLoader().getResourceAsStream(propertiesFileName);

			if (inputStream != null) {
				properties.load(inputStream);

				value = properties.getProperty(key);
			} else {
				throw new FileNotFoundException(
						"property file '" + propertiesFileName + "' not found in the classpath");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return value;
	}

}
