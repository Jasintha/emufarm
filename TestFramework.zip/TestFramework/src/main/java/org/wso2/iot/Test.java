package org.wso2.iot;

import org.json.JSONArray;
import org.json.JSONObject;

public class Test {
	
	public static void main(String[] args) {
		
		  JSONObject test1 = new JSONObject();
		  test1.put("name", "jasintha");
		  test1.put("ip", "1212131233");
		  
		  JSONObject test2 = new JSONObject();
		  test2.put("name", "jasintha");
		  test2.put("ip", "1212131233");
		  		  
		  JSONObject test3 = new JSONObject();
		  test3.put("name", "jasintha");
		  test3.put("ip", "1212131233");
		  
		//  String jsonStr="{"+test1.toString()+`"}";
		  
		  JSONArray jsonArray = new JSONArray();
		  jsonArray.put(test1);
		  jsonArray.put(test2);
		  jsonArray.put(test3);
		  
		  JSONObject jsonObject = new JSONObject();
		  jsonObject.put("", test1);
		  jsonObject.put("", test2);
		  jsonObject.put("", test3);
 
		System.out.println(jsonArray.toString());
		 
		JSONArray jsonArray2 = new JSONArray(jsonArray.toString());
		
		for (Object object : jsonArray2) {
			JSONObject object2 = (JSONObject) object;
			System.out.println(object2.get("ip"));
		}
		
	}
	
	/*
	@Path("/hello")
	public class Hello {

	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  @Consumes(MediaType.APPLICATION_JSON)
	  public JSONObject sayPlainTextHello(JSONObject inputJsonObj) throws Exception {

	    String input = (String) inputJsonObj.get("input");
	    String output = "The input you sent is :" + input;
	    JSONObject outputJsonObj = new JSONObject();
	    outputJsonObj.put("output", output);

	    return outputJsonObj;
	  }
	}
	
	ClientConfig config = new DefaultClientConfig();
	  Client client = Client.create(config);
	  client.addFilter(new LoggingFilter());
	  WebResource service = client.resource(getBaseURI());
	  JSONObject inputJsonObj = new JSONObject();
	  inputJsonObj.put("input", "Value");
	  System.out.println(service.path("rest").path("hello").accept(MediaType.APPLICATION_JSON).post(JSONObject.class, inputJsonObj));
	*/

}
