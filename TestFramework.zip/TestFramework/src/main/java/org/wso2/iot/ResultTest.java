package org.wso2.iot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.swing.text.StyledEditorKit.ForegroundAction;

/**
 * Created by jasintha on 10/7/16.
 */
public class ResultTest {

    public static void main(String[] args) {

        Runtime runtime = Runtime.getRuntime();
        Process process = null;
        StringBuffer processOutput = new StringBuffer();
        StringBuffer processError = new StringBuffer();
        String respond="";
        String opname="targets";
        String deviceId="emulator-5554";
        try{

            String outInput = "";
            String outError = "";
            String cmd="";




            if("lad".equals(opname)){

                cmd = "adb devices";
            }else if("log".equals(opname)){

                cmd = "adb -s "+deviceId+" logcat";

            }else if("kill".equals(opname)){

                cmd = "adb -s "+deviceId+" emu kill";
            }else if("targets".equals(opname)){
            	
            	  cmd = "/Users/jasintha/Library/Android/sdk/tools/android list target";
            }



            //  String cmd = "adb -s emulator-5554 logcat";
            //   String cmd2 ="adb devices";

            process = runtime.exec(cmd);

            BufferedReader stdInput = new BufferedReader(new
                    InputStreamReader(process.getInputStream()));

            BufferedReader stdError = new BufferedReader(new
                    InputStreamReader(process.getErrorStream()));

          

            while ((outInput = stdInput.readLine()) != null) {
            	
               if(outInput!=null && outInput.startsWith("-----")){
            	   processOutput.append("\n");
               	}
            	if(outInput!=null && (outInput.startsWith("id:") || outInput.contains("default/x86"))){
            		
            			 processOutput.append(outInput); 
            	}
            	
              
            }


            while ((outError = stdError.readLine()) != null) {
                processError.append(outError + "\n");
            }



        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            process.destroy();
        }


        if("lad".equals(opname)){
            String result = processOutput.toString();
            String lines[] = result.split("\\r?\\n");


            for(int j=1 ; j < lines.length;j++){

                if(j!=1){
                    respond = respond +","+ lines[j].split("\\s+")[0];
                }else{
                    respond = respond + lines[j].split("\\s+")[0];
                }


            }


        }else if("log".equals(opname)){

            respond = processOutput.toString();
        }else if("targets".equals(opname)){
        	
        	String result = processOutput.toString();
            String lines[] = result.split("\\r?\\n");
            for (String string : lines) {
				
            	if(string.contains("Tag/ABIs")){
            		respond=respond+"\n"+string.split("\\s+")[3];
            		
            		
            	}
			}
        	
        }

        System.out.println(respond);

    }

}
