#!/bin/bash

function showUsageAndExit() {
  echo "Insufficient or invalid options provided!"
  echo
  echo "Usage: ./testscript.sh -d [device] -n [noOfDevices] -a [agentUrl]"
  echo

  echo "Options:"
  echo
  echo -en "  -d\t"
  echo "[REQUIRED] Comma separated list of product codes. [esb,is,apim,das][all]"
  echo -en "  -n\t"
  echo "[OPTIONAL] Platform to setup Hiera data. If none given 'default' platform will be taken"
  echo -en "  -a\t"
  echo "[OPTIONAL] Product version. If none given latest version will be taken. Multiple products not supported."
  echo

  echo "Ex: ./testscript.sh -d A1 -n 2 -a https://iotserver.com/agent1 "

  echo
  exit 1
}

function startAvd () {

  echo "\n android_api : ${1} \n EMM_HOST : ${2} \n port : ${3} \n emuType : ${4} \n apk :${apk} \n count : ${6}";

    EMULATOR_PORT=$((${3} + (${6} * 2)))

    echo "\t\t \n\n ****************** Step 1 - Creating the AVD ************************"

    echo no | android create avd -f -n avd-${EMULATOR_PORT} -t ${1} --abi default/x86

    echo "\t\t \n\n ****************** Step 2 - Starting the emulator using avd-${EMULATOR_PORT} ************************"

    ${4} -netdelay none -netspeed full -avd avd-${EMULATOR_PORT} -port ${EMULATOR_PORT}  -no-window &
    #emulator -netdelay none -netspeed full -avd ${AVD_NAME} -port ${EMULATOR_PORT}   -no-window

    echo "Emulater is loading ....."
    while [ "`adb -s emulator-${EMULATOR_PORT} get-state`" != "device" ] ;do sleep 2; done

    sleep 1 ;
    echo "Emulater getting ready to install agent"
    retrycout=0;
    timeout=120;
    while [ "`adb -s emulator-${EMULATOR_PORT} shell getprop sys.boot_completed | tr -d '\r' `" != "1" ] ;
          do

            let retrycout=retrycout+1;
           if [ ${retrycout} -lt ${timeout} ] ; then
               echo "Emulater still booting ... ${retrycout}  retry after 1 seconds"
               sleep 1;
            else
              echo "emulator couldn't started "
              break;
           fi
    done

    echo "Sending... the mobile agent into the device"
    adb -s emulator-${EMULATOR_PORT} push ${5} /data/local/tmp/org.wso2.emm.agent

    echo "installing... the agent"
    adb -s emulator-${EMULATOR_PORT} shell pm install -r "/data/local/tmp/org.wso2.emm.agent"

    echo "executing... the application"
    adb -s emulator-${EMULATOR_PORT} shell am start -n "org.wso2.emm.agent/org.wso2.emm.agent.AgentReceptionActivity" -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -e host ${2} &

}


while getopts :d:n:a:i:e:p: FLAG; do
  case ${FLAG} in
    d)
      device=$OPTARG
      ;;
    n)
      noOfDevices=$OPTARG
      ;;
    a)
      emmUrl=$OPTARG
      ;;
    i)
      port=$OPTARG
      ;;
    e)
      emuType=$OPTARG
      ;;
    p)
      apk=$OPTARG
      ;;
    \?)
      showUsageAndExit
      ;;
  esac
done

echo "Device: ${device} _+_ NoOfDevices: ${noOfDevices} _+_ emmUrl: ${emmUrl} _+_port: ${port} _+_emuType: ${emuType} APK: ${apk}";

COUNTER=0
while [  ${COUNTER} -lt ${noOfDevices} ]; do

    startAvd ${device} ${emmUrl} ${port} ${emuType} ${apk} ${COUNTER}
    let COUNTER=COUNTER+1
    sleep 1
done
exit 0
