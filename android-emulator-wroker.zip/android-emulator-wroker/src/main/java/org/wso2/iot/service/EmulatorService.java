/*
 * Copyright (c) 2016, WSO2 Inc. (http://wso2.com) All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.wso2.iot.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.wso2.iot.service.FindCertainExtension;

import org.json.JSONArray;
import org.json.JSONObject;



/**
 * This is the Microservice resource class.
 * See <a href="https://github.com/wso2/msf4j#getting-started">https://github.com/wso2/msf4j#getting-started</a>
 * for the usage of annotations.
 *
 * @since 1.0.0
 */
@Path("/iot")
public class EmulatorService {

	/*{"deviceType":"avd24","count":5,"emuType":"emulator","emmHost":"10.0.2.2:9763","apk":"null","script":"null"}*/
	private static final String EMU_START_SCRIPT = "emurunner.sh";

	private static final String API_19_DEVICE = "avd19";

	private static final String API_21_DEVICE = "avd21";

	private static final String API_22_DEVICE = "avd22";

	private static final String API_23_DEVICE = "avd23";

	private static final String API_24_DEVICE = "avd24";

	private static final String ADB_DEVICES_LIST_COMMAND = "adb devices";

	private static final String KILL_EMU = "kill";

	private static final String LOGS = "log";

	private static final Logger LOGGER = Logger.getLogger(EmulatorService.class.getName());

	private static final String propertiesFileName = "config/config.properties";
	public static final String List_AVILABLE_DEVICE = "lad";
	Properties properties = new Properties();

	InputStream inputStream;
	StringBuffer processError = new StringBuffer();
	StringBuffer processOutput = new StringBuffer();
	String deviceType;

	public String getProperties(String key) throws IOException {
		String value = "";
		try {
			inputStream = getClass().getClassLoader().getResourceAsStream(propertiesFileName);

			if (inputStream != null) {
				properties.load(inputStream);

				value = properties.getProperty(key);
			} else {
				throw new FileNotFoundException(
						"property file '" + propertiesFileName + "' not found in the classpath");
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getStackTrace().toString());
		}

		return value;
	}

	@GET
	@Path("/echo")
	public Response getMsg() throws Exception {
	
//		File file = new File(EmulatorService.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
//
//		String homeDir = System.getProperty("user.dir");		
//		System.out.println("HOME...."+file.getAbsolutePath());
//		
//		File  apk = new File(file.getParent().toString() + File.separator + "*.apk");
//	//	String output = "Running at "+apk.getAbsolutePath();
//				
//		String listFile = new FindCertainExtension().listFile(file.getParent().toString(), ".apk");
//		String output = "Running at "+listFile;
		String output="aasd";
		return Response.status(200).entity(output).build();

	}

	@POST
	@Path("/echopost")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getMsgpost(String request) throws Exception {
	
//		File file = new File(EmulatorService.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
//
//		String homeDir = System.getProperty("user.dir");		
//		System.out.println("HOME...."+file.getAbsolutePath());
//		
//		File  apk = new File(file.getParent().toString() + File.separator + "*.apk");
//	//	String output = "Running at "+apk.getAbsolutePath();
//				
//		String listFile = new FindCertainExtension().listFile(file.getParent().toString(), ".apk");
//		String output = "Running at "+listFile;
		String output="aasd";
		return Response.status(200).entity(output).build();

	}

	@GET
	@Path("/createemu/{device}/{noOfDevices}")
	public Response createTest(@PathParam("device") final String device,
			@PathParam("noOfDevices") final int noOfDevices)
			throws IOException, URISyntaxException {
		  String emuType="emulator";
	      String emmURL="10.0.2.2:9763";
	      String output = createEmulater(device, noOfDevices,emuType,emmURL,null,null);
		return Response.status(200).entity(output).build();
	}
	
	
	@POST
	@Path("/createemu")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response removeMachines(String deviceInfo) throws IOException {
	
		JSONObject deviceJson = new JSONObject(deviceInfo);
		
		String status="OK";
		try {		
			 // String emuType="emulator";
		     // String emmURL="10.0.2.2:9763";
		      createEmulater(deviceJson.getString("deviceType"), deviceJson.getInt("count"),
		    		  deviceJson.getString("emuType"),deviceJson.getString("emmHost"),deviceJson.getString("apk"),
		    		  deviceJson.getString("script"));	
		     
		} catch (Exception e) {
		  status="Fail";
		}	
		JSONArray machinesArray = new JSONArray();
		machinesArray.put(200);
		JSONObject resultJson = new JSONObject();
		resultJson.putOnce("status", status);
		machinesArray.put(resultJson);
		System.out.println(machinesArray.toString());
		return Response.status(200).entity(machinesArray.toString()).build();
	}

	private String createEmulater(final String device, final int noOfDevices, final String emuType,
			final String emmURL,final String apkLocation,final String scriptLocation)
			throws URISyntaxException {
		
		if (API_24_DEVICE.equals(device)) {
			deviceType = "android-24";
		} else if (API_23_DEVICE.equals(device)) {
			deviceType = "android-23";
		} else if (API_22_DEVICE.equals(device)) {
			deviceType = "android-22";
		} else if (API_21_DEVICE.equals(device)) {
			deviceType = "android-21";
		} else if (API_19_DEVICE.equals(device)) {
			deviceType = "android-19";
		}

		Thread anonymous = new Thread() {

			@Override
			public void run() {

				Runtime runtime = Runtime.getRuntime();
				Process process = null;
				String BASH = "/bin/bash";
				System.out.println("deviceType : "+deviceType);
				File serviceFile;
				try {
					serviceFile = new File(
							EmulatorService.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
		
				String toolHome = serviceFile.getParent().toString();
				String apk=apkLocation;
				
				if(apk==null|| apk.equalsIgnoreCase("null")){
					 apk = toolHome + File.separator + new FindCertainExtension().listFile(toolHome, ".apk");
				}	
				String emuScriptPath=scriptLocation;
				if(scriptLocation==null|| scriptLocation.equalsIgnoreCase("null") ){
					 emuScriptPath = toolHome + File.separator + EMU_START_SCRIPT;
				}	
				StringBuffer processOutput = new StringBuffer();
				StringBuffer processError = new StringBuffer();
				int port = 5554;
				String EmuListCmd = toolHome + File.separator + ".." + File.separator + "platform-tools"
							+ File.separator + ADB_DEVICES_LIST_COMMAND;
					
					process = cmdExcecuter(runtime, processOutput, processError, new String[] { EmuListCmd });
					String result = processOutput.toString();
					String lines[] = result.split("\\r?\\n");
					List<Integer> ports = new ArrayList<>();
					for (int num = 1; num < lines.length; num++) {
						ports.add(Integer.parseInt(lines[num].split("\\s+")[0].split("-")[1]));
					}
					if (!ports.isEmpty()) {
						Collections.reverse(ports);
						Integer lastport = ports.get(0);
						port = lastport + 4;
					}
					processOutput.delete(0, processOutput.length());

					String[] cmd = new String[] { BASH, emuScriptPath, "-d", deviceType, "-n",
							Integer.toString(noOfDevices), "-a", emmURL, "-i", Integer.toString(port), "-e", emuType,
							"-p", apk};
					

					process = cmdExcecuter(runtime, processOutput, processError, cmd);

				} catch (IOException | URISyntaxException e) {
					e.printStackTrace();
				} finally {
					process.destroy();
				}
			}

			private Process cmdExcecuter(Runtime runtime, StringBuffer processOutput, StringBuffer processError,
					String[] cmd) throws IOException {
				Process process;
				String outInput;
				String outError;
				if (cmd.length == 1) {
					process = runtime.exec(cmd[0]);
				} else {
					process = runtime.exec(cmd);
				}

				BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
				BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
				while ((outInput = stdInput.readLine()) != null) {
					System.out.println(outInput);
					processOutput.append(outInput + "\n");
				}
				while ((outError = stdError.readLine()) != null) {
					processError.append(outError + "\n");
					System.out.println(outError);
				}
				return process;
			}
		};
		anonymous.start();
		String output = "OK";
		return output;
	}

	@POST
	@Path("/emuoperation")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response execadb(String operationStr) {
	//	@PathParam("opname") final String opname, @PathParam("deviceId") final String deviceId
		//{"opname":"lad","deviceId":"emulator-5554","ip":"ip"}
		
		//Failure [INSTALL_FAILED_DEXOPT]
		
		JSONObject operation = new JSONObject(operationStr);
		String respond = "";
		JSONArray resultArray = new JSONArray();
		Thread anonymous = new Thread() {
			@Override
			public void run() {
				Runtime runtime = Runtime.getRuntime();
				Process process = null;
				try {
					File serviceFile = new File(
							EmulatorService.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());		
				   String toolHome = serviceFile.getParent().toString();
				   
					String outInput = "";
					String outError = "";
					String cmd = "";
					String opName = operation.getString("opname");
					if (List_AVILABLE_DEVICE.equals(opName)) {
						cmd = toolHome + File.separator + ".." + File.separator + "platform-tools"
								+ File.separator +ADB_DEVICES_LIST_COMMAND;
					} else if (LOGS.equals(opName)) {
						cmd = toolHome + File.separator + ".." + File.separator + "platform-tools"
								+ File.separator +"adb -s " + operation.getString("deviceId") + " logcat";
					} else if (KILL_EMU.equals(opName)) {
						cmd = toolHome + File.separator + ".." + File.separator + "platform-tools"
								+ File.separator +"adb -s " + operation.getString("deviceId") + " emu kill";
					} else if ("targets".equals(opName)) {
						cmd = toolHome + File.separator+"android list target";
					}else if("killAll".equals(opName)){
						cmd = toolHome + File.separator + ".." + File.separator + "platform-tools"
								+ File.separator + ADB_DEVICES_LIST_COMMAND;
					}
					
					process = cmdExcecuter(opName, runtime, cmd);

				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					process.destroy();
				}

			}

		private Process cmdExcecuter(final String opname, Runtime runtime, String cmd) throws IOException {
				Process process;
				String outInput;
				String outError;
				process = runtime.exec(cmd);
				BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
				BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
				while ((outInput = stdInput.readLine()) != null) {

					if ("targets".equals(opname)) {
						if (outInput != null && outInput.startsWith("-----")) {
							processOutput.append("\n");
						}
						if (outInput != null && (outInput.startsWith("id:") || outInput.contains("default/x86"))) {
							processOutput.append(outInput);
						}
					} else {
						processOutput.append(outInput + "\n");

					}
				}
				while ((outError = stdError.readLine()) != null) {
					processError.append(outError + "\n");
				}
				return process;
			}
		};
		anonymous.start();
		long startTime = System.currentTimeMillis();
		while (true) {
			if ((System.currentTimeMillis() - startTime) > 3000) {
				break;
			}
		}
		anonymous.stop();
		String machineIP = operation.getString("ip");
		if (List_AVILABLE_DEVICE.equals(operation.getString("opname"))) {
			
			String result = processOutput.toString();
			String lines[] = result.split("\\r?\\n");
			//JSONObject machine = new JSONObject();
			for (int num=1; num < lines.length; num++) {
				JSONObject device = new JSONObject();
				//lines[num].split("\\s+")[0]
				device.put("Name", lines[num].split("\\s+")[0]);				
				device.put("ip",machineIP);
				resultArray.put(device);
			}
			
			//JSONObject mainObject = new JSONObject();
			//mainObject.put("records", resultArray);
			respond = resultArray.toString();
		
		} else if (LOGS.equals(operation.getString("opname"))) {
			
			JSONObject mainObject = new JSONObject();
			respond = processOutput.toString();
			mainObject.putOnce("logs", respond);
			
		} else if ("targets".equals(operation.getString("opname"))) {
			
			String result = processOutput.toString();
			String lines[] = result.split("\\r?\\n");
			
			for (String line : lines) {
				if (line.contains("Tag/ABIs")) {
					respond = respond + "\n" + line.split("\\s+")[3];
					JSONObject targets = new JSONObject();
					targets.put("Id", line.split("\\s+")[0]);
					resultArray.put(targets);
				}
			}
		 }
		
		processOutput.delete(0, processOutput.length());
		return Response.status(200).entity(respond).build();
	}
	
	
	
	@POST
	@Path("/emuoperation/killAll")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response execadbkillAll(String operationStr) {
	//	@PathParam("opname") final String opname, @PathParam("deviceId") final String deviceId
		//{"opname":"lad","deviceId":"emu54","ip":"ip"}
		
		JSONObject operation = new JSONObject(operationStr);
		String respond = "";
		JSONArray resultArray = new JSONArray();
		Thread anonymous = new Thread() {
			@Override
			public void run() {
				Runtime runtime = Runtime.getRuntime();
				Process process = null;
				try {
					File serviceFile = new File(
							EmulatorService.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());		
				   String toolHome = serviceFile.getParent().toString();
				   
					String outInput = "";
					String outError = "";
					String cmd = "";
					String opName = operation.getString("opname");
					if (List_AVILABLE_DEVICE.equals(opName)) {
						cmd = ADB_DEVICES_LIST_COMMAND;
					} else if (LOGS.equals(opName)) {
						cmd = "adb -s " + operation.getString("deviceId") + " logcat";
					} else if (KILL_EMU.equals(opName)) {
						cmd = "adb -s " + operation.getString("deviceId") + " emu kill";
					} else if ("targets".equals(opName)) {

						cmd = "/Users/jasintha/Library/Android/sdk/tools/android list target";
					}else if("killAll".equals(opName)){
						cmd = toolHome + File.separator + ".." + File.separator + "platform-tools"
								+ File.separator + ADB_DEVICES_LIST_COMMAND;
					}
					
					process = cmdExcecuter(opName, runtime, cmd);

				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					process.destroy();
				}

			}

		private Process cmdExcecuter(final String opname, Runtime runtime, String cmd) throws IOException {
				Process process;
				String outInput;
				String outError;
				process = runtime.exec(cmd);
				BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
				BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
				while ((outInput = stdInput.readLine()) != null) {

					if ("targets".equals(opname)) {
						if (outInput != null && outInput.startsWith("-----")) {
							processOutput.append("\n");
						}
						if (outInput != null && (outInput.startsWith("id:") || outInput.contains("default/x86"))) {
							processOutput.append(outInput);
						}
					} else {
						processOutput.append(outInput + "\n");

					}
				}
				while ((outError = stdError.readLine()) != null) {
					processError.append(outError + "\n");
				}
				return process;
			}
		};
		anonymous.start();
		long startTime = System.currentTimeMillis();
		while (true) {
			if ((System.currentTimeMillis() - startTime) > 3000) {
				break;
			}
		}
		anonymous.stop();
		String machineIP = operation.getString("ip");
		if (List_AVILABLE_DEVICE.equals(operation.getString("opname"))) {
			
			String result = processOutput.toString();
			String lines[] = result.split("\\r?\\n");
			
			for (int num=1; num < lines.length; num++) {
				JSONObject device = new JSONObject();
				//lines[num].split("\\s+")[0]
				device.put("Name", lines[num].split("\\s+")[0]);				
				device.put("ip",machineIP);
				resultArray.put(device);
			}
			
			JSONObject mainObject = new JSONObject();
			mainObject.put("records", resultArray);
			respond = "" + mainObject;
		
		} else if (LOGS.equals(operation.getString("opname"))) {
			
			JSONObject mainObject = new JSONObject();
			respond = processOutput.toString();
			mainObject.putOnce("logs", respond);
			
		} else if ("targets".equals(operation.getString("opname"))) {
			
			String result = processOutput.toString();
			String lines[] = result.split("\\r?\\n");
			
			for (String line : lines) {
				if (line.contains("Tag/ABIs")) {
					respond = respond + "\n" + line.split("\\s+")[3];
					JSONObject targets = new JSONObject();
					targets.put("Id", line.split("\\s+")[0]);
					resultArray.put(targets);
				}
			}
		 } else if("killAll".equals(operation.getString("opname"))){
			
			String result = processOutput.toString();
			String lines[] = result.split("\\r?\\n");
			List<Integer> ports = new ArrayList<>();
			for (int num = 1; num < lines.length; num++) {
				String cmd ="adb -s "+lines[num].split("\\s+")[0] +"emu kill";
				//cmdExcecuter
			}
			 
			processOutput.delete(0, processOutput.length());
			
			
		}
		
		processOutput.delete(0, processOutput.length());
		return Response.status(200).entity(respond).build();
	}
	
	
	

}
