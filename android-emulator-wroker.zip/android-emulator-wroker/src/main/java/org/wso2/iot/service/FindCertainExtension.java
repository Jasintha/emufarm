package org.wso2.iot.service;

import java.io.*;

public class FindCertainExtension {


	public String listFile(String folder, String ext) {

		GenericExtFilter filter = new GenericExtFilter(ext);
		File dir = new File(folder);
		String[] list = dir.list(filter);
		return list[0];
	}

	// inner class, generic extension filter
	public class GenericExtFilter implements FilenameFilter {

		private String ext;
		public GenericExtFilter(String ext) {
			this.ext = ext;
		}
		public boolean accept(File dir, String name) {
			return (name.endsWith(ext));
		}
	}
}